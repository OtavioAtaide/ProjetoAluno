package aluno;
import java.util.Scanner;

class Aluno {
    private String nome;
    private String matricula;
    private String sexo;
    private String dataNascimento;
    private String curso;
    private int anoInicio;
    private double notaProva1;
    private double notaProva2;
    private double mediaTrabalhos;

    // Getters e Setters
    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMatricula() {
        return this.matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getSexo() {
        return this.sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getDataNascimento() {
        return this.dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getCurso() {
        return this.curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public int getAnoInicio() {
        return this.anoInicio;
    }

    public void setAnoInicio(int anoInicio) {
        this.anoInicio = anoInicio;
    }

    public double getNotaProva1() {
        return this.notaProva1;
    }

    public void setNotaProva1(double notaProva1) {
        this.notaProva1 = notaProva1;
    }

    public double getNotaProva2() {
        return this.notaProva2;
    }

    public void setNotaProva2(double notaProva2) {
        this.notaProva2 = notaProva2;
    }

    public double getMediaTrabalhos() {
        return this.mediaTrabalhos;
    }

    public void setMediaTrabalhos(double mediaTrabalhos) {
        this.mediaTrabalhos = mediaTrabalhos;
    }

    
    public boolean isAprovado() {
        double mediaFinal = (notaProva1 + notaProva2 + mediaTrabalhos) / 3;
        return mediaFinal >= 6.0;
    }

    public double calcularMediaFinal() {
        return (notaProva1 + notaProva2 + mediaTrabalhos) / 3;
    }
}

public class Aluno2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Aluno aluno = new Aluno();

        System.out.println(">>> INÍCIO SOFTWARE ALUNO <<<");
        System.out.print("Informe o nome do aluno: ");
        aluno.setNome(scanner.nextLine());
        
        System.out.print("Informe a matrícula: ");
        aluno.setMatricula(scanner.nextLine());
        
        System.out.print("Informe o sexo: ");
        aluno.setSexo(scanner.nextLine());
        
        System.out.print("Informe a data de nascimento: ");
        aluno.setDataNascimento(scanner.nextLine());
        
        System.out.print("Informe o Curso: ");
        aluno.setCurso(scanner.nextLine());
        
        System.out.print("Informe o ano de início: ");
        aluno.setAnoInicio(scanner.nextInt());
        
        System.out.print("Informe a Nota da Prova 1: ");
        aluno.setNotaProva1(scanner.nextDouble());
        
        System.out.print("Informe a Nota da Prova 2: ");
        aluno.setNotaProva2(scanner.nextDouble());
        
        System.out.print("Informe a média dos Trabalhos: ");
        aluno.setMediaTrabalhos(scanner.nextDouble());

        System.out.println("### INFORMAÇÕES ###");
        System.out.println("Nome: " + aluno.getNome());
        System.out.println("Matrícula: " + aluno.getMatricula());
        System.out.println("Curso: " + aluno.getCurso());
        
        if (aluno.isAprovado()) {
            System.out.printf("Situação: Aprovado com média %.2f%n", aluno.calcularMediaFinal());
        } else {
            System.out.printf("Situação: Reprovado com média %.2f%n", aluno.calcularMediaFinal());
        }

        System.out.println(">> Fim da execução do software <<<");
        scanner.close();
    }
}

